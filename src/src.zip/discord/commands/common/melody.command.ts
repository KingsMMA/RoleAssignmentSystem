import BaseCommand from "../base.command"
import TemplateBot from "../../TemplateBot"
import { ApplicationCommandType, ApplicationCommandOptionType } from "discord-api-types/v10"
import {
    AutocompleteInteraction,
    ChatInputCommandInteraction, EmbedBuilder,
    PermissionOverwrites,
    PermissionsBitField
} from "discord.js"
import KingEmbedBuilder from "../../utils/KingEmbedBuilder";

const s_maximum = 6.0;

export default class HelpCommand extends BaseCommand {
    constructor(client: TemplateBot) {
        super(client, {
            name: "melody",
            description: "Calculate the chance of a given melody time occurring",
            type: ApplicationCommandType.ChatInput,
            default_member_permissions:
                PermissionsBitField.Flags.Administrator.toString(),
            options: [
                {
                    name: "time",
                    description: "The time taken for the melody",
                    type: ApplicationCommandOptionType.Number,
                    required: true,
                },
                {
                    name: "ping",
                    description: "The ping of the player in milliseconds",
                    type: ApplicationCommandOptionType.Integer,
                    required: true,
                }
            ]
        })
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const time = interaction.options.getNumber('time', true);
        const ping = interaction.options.getInteger('ping', true);
        const average = 5.4 + (0.00224)*(ping+250) + (0.004)*(ping+100)
        const sd = Math.sqrt(Math.pow(average, 2) / 19 )
        const z = (time - average) / sd;
        if (z > s_maximum) {
            return interaction.reply({
                embeds: [
                    new KingEmbedBuilder()
                        .setTitle('Melody Calculator')
                        .setColor('Red')
                        .setDescription('The time taken is too high.')
                ]
            })
        }
        if (ping <= 0 || ping >= 500) {
            return interaction.reply({
                embeds: [
                    new KingEmbedBuilder()
                        .setTitle('Melody Calculator')
                        .setColor('Red')
                        .setDescription(ping < 200 ? 'Your ping is too low.  Please move to Australia, connect to 6 VPNs at once, or take a hammer to your router.' : 'Your ping is too high.  Please move to the Australia, quit Skyblock, or cry.')
                ]
            })
        }

        var lp = this.maxpscore(z);
        let response = (lp * 100);
        let above50 = response >= 50;
        if (above50) response = Math.abs(100 - response);

        return interaction.reply({
            embeds: [
                new KingEmbedBuilder()
                    .setTitle('Melody Calculator')
                    .setColor('Green')
                    .setDescription(
                        !above50 ?
                            `There is a **${response.toFixed(2)}%** chance of a perfectly played melody being **${time} seconds** or less with **${ping}ms** ping.` :
                            `There is a **${response.toFixed(2)}%** chance of a perfectly played melody being **${time} seconds** or more with **${ping}ms** ping.`)
            ]
        })
    }

    maxpscore(z: number) {
        let y, x, w;
        if (z === 0.0) {
            x = 0.0;
        } else {
            y = 0.5 * Math.abs(z);
            if (y > (s_maximum * 0.5)) {
                x = 1.0;
            } else if (y < 1.0) {
                w = y * y;
                x = ((((((((0.000124818987 * w
                                - 0.001075204047) * w + 0.005198775019) * w
                            - 0.019198292004) * w + 0.059054035642) * w
                        - 0.151968751364) * w + 0.319152932694) * w
                    - 0.531923007300) * w + 0.797884560593) * y * 2.0;
            } else {
                y -= 2.0;
                x = (((((((((((((-0.000045255659 * y
                                            + 0.000152529290) * y - 0.000019538132) * y
                                        - 0.000676904986) * y + 0.001390604284) * y
                                    - 0.000794620820) * y - 0.002034254874) * y
                                + 0.006549791214) * y - 0.010557625006) * y
                            + 0.011630447319) * y - 0.009279453341) * y
                        + 0.005353579108) * y - 0.002141268741) * y
                    + 0.000535310849) * y + 0.999936657524;
            }
        }
        return z > 0.0 ? ((x + 1.0) * 0.5) : ((1.0 - x) * 0.5);
    }

}
